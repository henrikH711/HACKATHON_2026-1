import React, { useState, useEffect, useRef } from 'react';
import { StyleSheet, Text, View, ScrollView, TouchableOpacity, FlatList, ImageBackground, Animated, Image, Modal } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';

import coverImg from './assets/bassfest.jpg';

const FESTIVAL_DATA = {
  name: "BASS FEST",
  startDate: new Date("2026-07-09T20:00:00"),
  program: [
    { id: "j9_b1", date: "Július 9", artist: "Carv", start: "20:00", end: "21:30", stage: "BLACKOUT (Main Stage)", image: require('./Artists/carv.webp'), bio: "A modern hard techno szcéna egyik leggyorsabban feltörekvő producere. Sötét, indusztriális atmoszféra és fémesen kongó, nehéz ütemek." },
    { id: "j9_b2", date: "Július 9", artist: "KARAH", start: "21:30", end: "23:00", stage: "BLACKOUT (Main Stage)", image: require('./Artists/karah.jpg'), bio: "A sötét és az energikus rave-hangulat tökéletes egyensúlya, acid és trance elemekkel a kora kétezres évekből." },
    { id: "j9_b3", date: "Július 9", artist: "Basswell", start: "23:00", end: "01:00", stage: "BLACKOUT (Main Stage)", image: require('./Artists/basswell.jpg'), bio: "Francia energiabomba. A 90-es évek underground rave kultúrája éled újjá modern, bivalyerős hangzással." },
    { id: "j9_b4", date: "Július 9", artist: "Klangkuenstler", start: "01:00", end: "03:00", stage: "BLACKOUT (Main Stage)", image: require('./Artists/klangkuenstler.jpg'), bio: "A műfaj abszolút királya. Kíméletlen, loop-orientált schranz és nyers indusztriális pusztítás a legmagasabb szinten." },
    { id: "j9_a1", date: "Július 9", artist: "Daniella da Silva", start: "20:00", end: "21:30", stage: "APEX Stage", image: require('./Artists/danielladasilva.jpg'), bio: "Kíméletlen, de rendkívül elegáns ritmika sötét analóg acid szintifutamokkal fűszerezve." },
    { id: "j9_a2", date: "Július 9", artist: "Hot X", start: "21:30", end: "23:00", stage: "APEX Stage", image: require('./Artists/hotx.jpg'), bio: "A magyar techno kultúra abszolút alapító atyja és élő legendája. Hipnotikus loopok és sötét energiák." },
    { id: "j9_a3", date: "Július 9", artist: "Amelie Lens", start: "23:00", end: "01:00", stage: "APEX Stage", image: require('./Artists/amelielens.webp'), bio: "Globális szupersztár. Gyors, pattogós dobgépek, hipnotikus vokálok és szirénázó acid hullámok." },
    { id: "j9_a4", date: "Július 9", artist: "Ben Klock", start: "01:00", end: "03:00", stage: "APEX Stage", image: require('./Artists/benklock.jpg'), bio: "Berlin és a Berghain zenei arca. Nyers, funkcionális és nehéz indusztriális ütemek." },
    { id: "j9_e1", date: "Július 9", artist: "Marie Vaunt", start: "20:00", end: "21:30", stage: "ECLIPSE Arena", image: require('./Artists/marievaunt.jpg'), bio: "Sötét, atmoszférikus és dallamos techno, gótikus és filmzenés hangulatú lüktetéssel." },
    { id: "j9_e2", date: "Július 9", artist: "Cloudy", start: "21:30", end: "23:00", stage: "ECLIPSE Arena", image: require('./Artists/cloudy.jpg'), bio: "Kíméletlen indusztriális és schranz ütemek keverve a 90-es évek dance-remixeivel." },
    { id: "j9_e3", date: "Július 9", artist: "999999999", start: "23:00", end: "01:00", stage: "ECLIPSE Arena", image: require('./Artists/999999999.jpg'), bio: "Olasz duó, hardveres Live Act. Analóg gékezéssel generált száguldó tempó és torzított sav-menetek." },
    { id: "j9_e4", date: "Július 9", artist: "Timmy Trumpet", start: "01:00", end: "03:00", stage: "ECLIPSE Arena", image: require('./Artists/timmytrumpet.jpg'), bio: "A legnagyobb showman. Hardstyle, psy-trance és pörgős hard-dance elemek élő trombitával." },
    { id: "j9_p1", date: "Július 9", artist: "KAYZO", start: "20:00", end: "21:30", stage: "PSYCHO Stage", image: require('./Artists/kayzoo.jpg'), bio: "A heavy metál nyers, zúzós energiája keveredik a legdurvább dubstep és hard dance ütemekkel." },
    { id: "j9_p2", date: "Július 9", artist: "Riot Shift", start: "21:30", end: "23:00", stage: "PSYCHO Stage", image: require('./Artists/riotshift.jpg'), bio: "Német rawstyle duó, akik a metalcore és a punk-rock kultúrát viszik be a rave-szcénába." },
    { id: "j9_p3", date: "Július 9", artist: "Aversion", start: "23:00", end: "01:00", stage: "PSYCHO Stage", image: require('./Artists/aversion.jpg'), bio: "Monumentális rawstyle dallamok szétzúzva modern, csattanós és innovatív kickekkel." },
    { id: "j9_p4", date: "Július 9", artist: "Sub Zero Project", start: "01:00", end: "03:00", stage: "PSYCHO Stage", image: require('./Artists/subzeroproject.jpeg'), bio: "A hard-dance kultúra úttörői. Futurisztikus audio-vizuális utazás és kreatív sound-design." },
 
    { id: "j10_b1", date: "Július 10", artist: "Charlotte De Witte", start: "20:00", end: "21:30", stage: "BLACKOUT (Main Stage)", image: require('./Artists/charlottedewitte.jpg'), bio: "A KNTXT alapítója. Precíz építkezés, monumentális basszusok és lüktető acid szintik." },
    { id: "j10_b2", date: "Július 10", artist: "Technokool", start: "21:30", end: "23:00", stage: "BLACKOUT (Main Stage)", image: require('./Artists/technokool.jpg'), bio: "A hazai underground kulcsfigurája. Nyers indusztriális hangzás és gyors, zakatoló schranz ütemek." },
    { id: "j10_b3", date: "Július 10", artist: "Restricted", start: "23:00", end: "01:00", stage: "BLACKOUT (Main Stage)", image: require('./Artists/restricted.jpg'), bio: "Ausztrál kedvenc. Underground techno és populárisabb hard dance fúziója." },
    { id: "j10_b4", date: "Július 10", artist: "Angerfist", start: "01:00", end: "03:00", stage: "BLACKOUT (Main Stage)", image: require('./Artists/angerfist.jpg'), bio: "A hardcore zene élő legendája. Kíméletlen, agresszív uptempo darálás." },
    { id: "j10_a1", date: "Július 10", artist: "Jowi", start: "20:00", end: "21:30", stage: "APEX Stage", image: require('./Artists/jowi.jpg'), bio: "Kora kétezres évek indusztriális schranz ütemei és a modern fesztivál-hard-techno fúziója." },
    { id: "j10_a2", date: "Július 10", artist: "Charlie Sparks", start: "21:30", end: "23:00", stage: "APEX Stage", image: require('./Artists/charliesparks.jpg'), bio: "Sötét indusztriális techno nyers ereje mossa össze hipnotikus acid hullámokkal." },
    { id: "j10_a3", date: "Július 10", artist: "Alignment", start: "23:00", end: "01:00", stage: "APEX Stage", image: require('./Artists/alignment.jpg'), bio: "Kapocs a nosztalgikus neo-rave és a kemény hard techno között száguldó szintifutamokkal." },
    { id: "j10_a4", date: "Július 10", artist: "6EJOU", start: "01:00", end: "03:00", stage: "APEX Stage", image: require('./Artists/6ejou.jpg'), bio: "Teljesen élő analóg live act szintetizátorokkal. Kiszámíthatatlan, nyers kohó-techno." },
    { id: "j10_e1", date: "Július 10", artist: "DJ Bountyhunter", start: "20:00", end: "21:30", stage: "ECLIPSE Arena", image: require('./Artists/djbountyhunter.jpg'), bio: "A Bonzai Records alaposzlopa. Nosztalgikus időutazás a korai hardcore világába." },
    { id: "j10_e2", date: "Július 10", artist: "Anxhela", start: "21:30", end: "23:00", stage: "ECLIPSE Arena", image: require('./Artists/anxhela.jpg'), bio: "Kíméletlen, fémes lüktetés hipnotikus acid dallamokkal és sötét, gótikus vokálokkal." },
    { id: "j10_e3", date: "Július 10", artist: "Oguz", start: "23:00", end: "01:00", stage: "ECLIPSE Arena", image: require('./Artists/oguz.jpg'), bio: "A 808 ASYLUM feje. Gyors schranz loopok pörgős hardstyle és industrial elemekkel." },
    { id: "j10_e4", date: "Július 10", artist: "I Hate Models", start: "01:00", end: "03:00", stage: "ECLIPSE Arena", image: require('./Artists/ihatemodels.jpg'), bio: "A fesztivál abszolút headlinere. Érzelmi hullámvasút a nyers indusztriálistól a trance-ig." },
    { id: "j10_p1", date: "Július 10", artist: "Dr Donk", start: "20:00", end: "21:30", stage: "PSYCHO Stage", image: require('./Artists/drdonk.jpg'), bio: "A bounce kultúrából ismert jellegzetes, gumilabda-szerűen pattogó donk hangzás." },
    { id: "j10_p2", date: "Július 10", artist: "Dual Damage", start: "21:30", end: "23:00", stage: "PSYCHO Stage", image: require('./Artists/dualdamage.jpg'), bio: "A legforróbb rawstyle szenzáció. Fém-a-fémhez csattanó, szürreális kickek." },
    { id: "j10_p3", date: "Július 10", artist: "Krowdexx", start: "23:00", end: "01:00", stage: "PSYCHO Stage", image: require('./Artists/krowdexx.jpg'), bio: "Olasz testvérpár. Elképesztő tempó és torzított basszusvariációk úthengerként." },
    { id: "j10_p4", date: "Július 10", artist: "Sickmode", start: "01:00", end: "03:00", stage: "PSYCHO Stage", image: require('./Artists/sickmode.jpg'), bio: "A rawstyle forradalmára. Energikus, játékos, váratlan ritmusváltások és kemény dropok." },
 
    { id: "j11_b1", date: "Július 11", artist: "JAURI", start: "20:00", end: "21:30", stage: "BLACKOUT (Main Stage)", image: require('./Artists/jauri.jpg'), bio: "A hazai underground motorja. Kíméletlen sötétség és indusztriális hangzás acid elemekkel." },
    { id: "j11_b2", date: "Július 11", artist: "Novah", start: "21:30", end: "23:00", stage: "BLACKOUT (Main Stage)", image: require('./Artists/novah.webp'), bio: "Belga tehetség. Sötét indusztriális ütemek és a kora kétezres évek rave-hangulatának fúziója." },
    { id: "j11_b3", date: "Július 11", artist: "POLTERGST", start: "23:00", end: "01:00", stage: "BLACKOUT (Main Stage)", image: require('./Artists/poltergst.jpg'), bio: "Disztópikus, cyberpunk jövő. Hard techno nyers ereje hardstyle kick-struktúrákkal." },
    { id: "j11_b4", date: "Július 11", artist: "Nico Moreno", start: "01:00", end: "03:00", stage: "BLACKOUT (Main Stage)", image: require('./Artists/nicomoreno.jpg'), bio: "Az Insolent Rave Records alapítója. Végig 160 BPM feletti fémes indusztriális rombolás." },
    { id: "j11_a1", date: "Július 11", artist: "Zeuz", start: "20:00", end: "21:30", stage: "APEX Stage", image: require('./Artists/zeuz.jpg'), bio: "Nyers gépies ritmusok és sötét, fojtogató földalatti hangulat felesleges sallangok nélkül." },
    { id: "j11_a2", date: "Július 11", artist: "Sara Landry", start: "21:30", end: "23:00", stage: "APEX Stage", image: require('./Artists/saralandry.webp'), bio: "A HEKATE feje. A legkeményebb underground darálást emeli stadionméretű szintre." },
    { id: "j11_a3", date: "Július 11", artist: "Winson", start: "23:00", end: "01:00", stage: "APEX Stage", image: require('./Artists/winson.webp'), bio: "Kíméletlen tempó ötvözve tiszta buli-energiával és retró rave-nosztalgiával." },
    { id: "j11_a4", date: "Július 11", artist: "Fantasm", start: "01:00", end: "03:00", stage: "APEX Stage", image: require('./Artists/fantasm.jpg'), bio: "Gépfegyver-szerű ritmusok, indusztriális gyári zajok és a legvadabb schranz ühetmek." },
    { id: "j11_e1", date: "Július 11", artist: "Uberrest", start: "20:00", end: "21:30", stage: "ECLIPSE Arena", image: require('./Artists/uberrest.jpg'), bio: "Sallangmentes hard techno és schranz. Ritmusok hipnotikus ismétlődése." },
    { id: "j11_e2", date: "Július 11", artist: "Zapravka", start: "21:30", end: "23:00", stage: "ECLIPSE Arena", image: require('./Artists/zapravka.jpeg'), bio: "Kőkemény 160+ BPM összehozva ugrálós bulihangulattal és ironikus dallamokkal." },
    { id: "j11_e3", date: "Július 11", artist: "Raxeller", start: "23:00", end: "01:00", stage: "ECLIPSE Arena", image: require('./Artists/raxeller.jpg'), bio: "Súlyos indusztriális dropok, mintha egy gyáróriás gépei indulnának be." },
    { id: "j11_e4", date: "Július 11", artist: "Holy Priest", start: "01:00", end: "03:00", stage: "ECLIPSE Arena", image: require('./Artists/holypriest.jpg'), bio: "Sötét, gépies zenei rituálé, klasszikus schranz darálás és sikító acid futamok." },
    { id: "j11_p1", date: "Július 11", artist: "GPF", start: "20:00", end: "21:30", stage: "PSYCHO Stage", image: require('./Artists/gpf.jpg'), bio: "A legőrültebb trash-hangulat és éles piep-kickek keverve popslágerek paródiáival." },
    { id: "j11_p2", date: "Július 11", artist: "Lil Texas", start: "21:30", end: "23:00", stage: "PSYCHO Stage", image: require('./Artists/liltexas.jpg'), bio: "Az amerikai uptempo nagykövete. 200+ BPM, torzított kickek és a trap elemek fúziója." },
    { id: "j11_p3", date: "Július 11", artist: "TOZA", start: "23:00", end: "01:00", stage: "PSYCHO Stage", image: require('./Artists/toza.jpg'), bio: "Ausztrál tehetség. Mesterien mossa össze a rawstyle-t az uptempo sebességével." },
    { id: "j11_p4", date: "Július 11", artist: "Dimitri K", start: "01:00", end: "03:00", stage: "PSYCHO Stage", image: require('./Artists/dimitrik.jpg'), bio: "Az uptempo hardcore abszolút királya. Gépfegyver-sebességű ritmikai terror." }
  ]
};

const Tab = createBottomTabNavigator();

export default function App() {
  const [favorites, setFavorites] = useState([]);
  const [selectedDate, setSelectedDate] = useState("Július 9");
  const [selectedArtist, setSelectedArtist] = useState(null);

  const toggleFavorite = (id) => {
    if (favorites.includes(id)) {
      setFavorites(favorites.filter(favId => favId !== id));
    } else {
      setFavorites([...favorites, id]);
    }
  };

  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.04, duration: 2500, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 2500, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  function DateTabs() {
    const dates = ["Július 9", "Július 10", "Július 11"];
    return (
      <View style={styles.tabBarContainer}>
        {dates.map((date) => {
          const isActive = selectedDate === date;
          return (
            <TouchableOpacity
              key={date}
              style={[styles.tabButton, isActive && styles.tabButtonActive]}
              onPress={() => setSelectedDate(date)}
            >
              <Text style={[styles.tabButtonText, isActive && styles.tabButtonTextActive]}>
                {date.toUpperCase()}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
    );
  }

  const renderProgramItem = ({ item }) => (
    <TouchableOpacity style={styles.card} onPress={() => setSelectedArtist(item)} activeOpacity={0.8}>
      <View style={styles.cardContent}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Image 
            source={item.image ? item.image : require('./Artists/carv.webp')} 
            style={styles.artistSquareImage} 
          />
          <View style={{ flex: 1 }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
              <Text style={styles.cardArtist}>{item.artist}</Text>
              <View style={styles.timeTag}>
                <Text style={styles.timeTagText}>{item.start} - {item.end}</Text>
              </View>
            </View>
            <Text style={styles.cardStage}>{item.stage}</Text>
          </View>
        </View>
      </View>
      <TouchableOpacity onPress={() => toggleFavorite(item.id)} style={styles.favoriteIconBox}>
        <Ionicons name={favorites.includes(item.id) ? "heart" : "heart-outline"} size={26} color={favorites.includes(item.id) ? "#00FFCC" : "#fff"} />
      </TouchableOpacity>
    </TouchableOpacity>
  );

  function HomeScreen({ navigation }) {
    const [timeLeft, setTimeLeft] = useState("");

    useEffect(() => {
      const interval = setInterval(() => {
        const now = new Date();
        const diff = FESTIVAL_DATA.startDate - now;
        if (diff <= 0) {
          setTimeLeft("A FESZTIVÁL ELKEZDŐDÖTT!");
          clearInterval(interval);
          return;
        }
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
        const mins = Math.floor((diff / 1000 / 60) % 60);
        const secs = Math.floor((diff / 1000) % 60);
        setTimeLeft(`${days} NAP ${hours}:${mins}:${secs}`);
      }, 1000);
      return () => clearInterval(interval);
    }, []);

    return (
      <View style={styles.container}>
        <Animated.View style={[styles.backgroundWrapper, { transform: [{ scale: pulseAnim }] }]}>
          <ImageBackground source={coverImg} style={styles.backgroundImage} />
        </Animated.View>

        <View style={styles.overlay}>
           <View style={styles.bottomSection}>
              <Text style={styles.countdownLabel}>STARTIG HÁTRALEVŐ IDŐ:</Text>
              <Text style={styles.countdownText}>{timeLeft}</Text>
              
              <TouchableOpacity
                style={styles.exploreButton}
                onPress={() => navigation.navigate('Program')}
              >
                <Text style={styles.exploreButtonText}>BELÉPÉS A FESZTIVÁLRA</Text>
                <Ionicons name="arrow-forward" size={18} color="#000" />
              </TouchableOpacity>
           </View>
        </View>
      </View>
    );
  }

  function ProgramScreen() {
    const filteredProgram = FESTIVAL_DATA.program.filter(item => item.date === selectedDate);
    return (
      <View style={styles.container}>
        <DateTabs />
        <FlatList
          data={filteredProgram}
          keyExtractor={(item) => item.id}
          renderItem={renderProgramItem}
          contentContainerStyle={{ paddingBottom: 20 }}
        />
      </View>
    );
  }

  function FavoritesScreen() {
    const favPrograms = FESTIVAL_DATA.program.filter(item => favorites.includes(item.id) && item.date === selectedDate);
    return (
      <View style={styles.container}>
        <DateTabs />
        {favPrograms.length === 0 ? (
          <View style={styles.centeredView}>
            <Ionicons name="heart-dislike-outline" size={64} color="#444" />
            <Text style={styles.noFavText}>Nincs kedvencelt programod erre a napra.</Text>
          </View>
        ) : (
          <FlatList
            data={favPrograms}
            keyExtractor={(item) => item.id}
            renderItem={renderProgramItem}
            contentContainerStyle={{ paddingBottom: 20 }}
          />
        )}
      </View>
    );
  }

  function MapScreen() {
    return (
      <View style={[styles.container, styles.centeredView]}>
        <Ionicons name="map-outline" size={50} color="#00FFCC" />
        <Text style={styles.menuTitle}>Fesztivál Térkép</Text>
        <View style={styles.mapGraphic}>
          <Text style={styles.mapPin}>🔊 BLACKOUT (Main Stage)</Text>
          <Text style={styles.mapPin}>⚡ APEX Stage</Text>
          <Text style={styles.mapPin}>🌌 ECLIPSE Arena</Text>
          <Text style={styles.mapPin}>🔥 PSYCHO Stage</Text>
          <Text style={styles.mapPin}>🍔 Gasztró Szekció</Text>
        </View>
      </View>
    );
  }

  function InfoScreen() {
    const foodStalls = [
      { id: "1", name: "Bass Burger", desc: "Szaftos burgerek, ropogós krumpli és brutál szószok.", offer: "Dupla techno burger menü" },
      { id: "2", name: "Rave Pizza", desc: "Gyors pizzaszeletek hajnalig, klasszikus és csípős feltétekkel.", offer: "Pepperoni bass slice" },
      { id: "3", name: "Neon Noodle", desc: "Ázsiai tészták, wok ételek és extra csípős szószok.", offer: "Chili rave noodles" },
      { id: "4", name: "Hardcore Hotdog", desc: "Felturbózott hotdogok hagymával, sajttal és erős szósszal.", offer: "Inferno hotdog" },
      { id: "5", name: "Afterparty Lángos", desc: "Friss lángos tejföllel, sajttal vagy extra feltétekkel.", offer: "Sajtos-tejfölös mega lángos" }
    ];

    return (
      <View style={styles.container}>
        <ScrollView>
          <Text style={styles.menuTitle}>Gasztró / Infó</Text>
          {foodStalls.map((item) => (
            <View key={item.id} style={styles.card}>
              <View style={styles.cardContent}>
                <Text style={styles.cardArtist}>{item.name}</Text>
                <Text style={styles.cardStage}>{item.desc}</Text>
                <Text style={[styles.cardBio, { color: '#00FFCC', marginTop: 8, fontSize: 13 }]}>Ajánlat: {item.offer}</Text>
              </View>
            </View>
          ))}
          <View style={{ height: 30 }} />
        </ScrollView>
      </View>
    );
  }

  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ color, size }) => {
            let iconNames = { 'Kezdőlap': 'home', 'Program': 'calendar', 'Menetrend': 'heart', 'Térkép': 'map', 'Gasztró/Infó': 'fast-food' };
            return <Ionicons name={iconNames[route.name]} size={size} color={color} />;
          },
          tabBarActiveTintColor: '#00FFCC',
          tabBarInactiveTintColor: '#666',
          tabBarStyle: { backgroundColor: '#000', borderTopWidth: 0, height: 60, paddingBottom: 10 },
          headerStyle: { backgroundColor: '#000', shadowColor: 'transparent', elevation: 0 },
          headerTintColor: '#fff',
        })}
      >
        <Tab.Screen name="Kezdőlap" component={HomeScreen} options={{ headerShown: false }} />
        <Tab.Screen name="Program" component={ProgramScreen} />
        <Tab.Screen name="Menetrend" component={FavoritesScreen} />
        <Tab.Screen name="Térkép" component={MapScreen} />
        <Tab.Screen name="Gasztró/Infó" component={InfoScreen} />
      </Tab.Navigator>

      {/* ADATLAP MODAL (FELÚSZÓ ABLAK) */}
      <Modal
        visible={selectedArtist !== null}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setSelectedArtist(null)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            
            {/* Fejléc ikon a bezáráshoz */}
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>ELŐADÓ ADATLAP</Text>
              <TouchableOpacity onPress={() => setSelectedArtist(null)} style={styles.closeIcon}>
                <Ionicons name="close-circle" size={30} color="#fff" />
              </TouchableOpacity>
            </View>

            {selectedArtist && (
              <ScrollView contentContainerStyle={styles.modalScroll}>
                <Image 
                  source={selectedArtist.image ? selectedArtist.image : require('./Artists/carv.webp')} 
                  style={styles.modalArtistImage} 
                />
                <Text style={styles.modalArtistName}>{selectedArtist.artist}</Text>
                
                <View style={styles.modalInfoRow}>
                  <View style={styles.modalTag}>
                    <Ionicons name="time-outline" size={14} color="#00FFCC" style={{ marginRight: 5 }} />
                    <Text style={styles.modalTagText}>{selectedArtist.start} - {selectedArtist.end}</Text>
                  </View>
                  <View style={styles.modalTag}>
                    <Ionicons name="location-outline" size={14} color="#00FFCC" style={{ marginRight: 5 }} />
                    <Text style={styles.modalTagText}>{selectedArtist.stage}</Text>
                  </View>
                </View>

                <Text style={styles.modalBioTitle}>Bemutatkozás</Text>
                <Text style={styles.modalBioText}>{selectedArtist.bio}</Text>

                <TouchableOpacity style={styles.modalCloseButton} onPress={() => setSelectedArtist(null)}>
                  <Text style={styles.modalCloseButtonText}>BEZÁRÁS</Text>
                </TouchableOpacity>
              </ScrollView>
            )}
          </View>
        </View>
      </Modal>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0a0a' },
  backgroundWrapper: { ...StyleSheet.absoluteFillObject },
  backgroundImage: { flex: 1, width: '100%', height: '100%', resizeMode: 'cover' },
  overlay: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.2)' },
  bottomSection: { padding: 30, alignItems: 'center', backgroundColor: 'rgba(10,10,10,0.85)', borderTopLeftRadius: 30, borderTopRightRadius: 30, paddingBottom: 40, borderTopWidth: 1, borderTopColor: '#222' },
  countdownLabel: { color: '#00FFCC', fontSize: 11, fontWeight: 'bold', letterSpacing: 3 },
  countdownText: { color: '#fff', fontSize: 28, fontWeight: 'bold', marginVertical: 12, letterSpacing: 1 },
  exploreButton: { flexDirection: 'row', backgroundColor: '#00FFCC', paddingVertical: 15, paddingHorizontal: 32, borderRadius: 30, alignItems: 'center', marginTop: 8 },
  exploreButtonText: { color: '#000', fontWeight: 'bold', marginRight: 8, fontSize: 13, letterSpacing: 1 },
  centeredView: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  tabBarContainer: { flexDirection: 'row', backgroundColor: '#000', padding: 8, marginHorizontal: 15, marginTop: 15, borderRadius: 15, borderWidth: 1, borderColor: '#222' },
  tabButton: { flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: 10 },
  tabButtonActive: { backgroundColor: '#161616', borderWidth: 1, borderColor: '#333' },
  tabButtonText: { color: '#666', fontSize: 11, fontWeight: 'bold', letterSpacing: 1 },
  tabButtonTextActive: { color: '#00FFCC' },
  card: { flexDirection: 'row', backgroundColor: '#121212', marginHorizontal: 15, marginTop: 15, borderRadius: 12, overflow: 'hidden', alignItems: 'center', borderWidth: 1, borderColor: '#1f1f1f', padding: 4 },
  cardContent: { padding: 16, flex: 1 },
  cardArtist: { color: '#fff', fontSize: 20, fontWeight: 'bold', letterSpacing: 0.5 },
  timeTag: { backgroundColor: '#1c1c1e', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 6, borderWidth: 1, borderColor: '#2c2c2e' },
  timeTagText: { color: '#fff', fontSize: 12, fontWeight: '600' },
  cardStage: { color: '#00FFCC', fontSize: 12, marginTop: 4, fontWeight: '700', letterSpacing: 1, textTransform: 'uppercase' },
  cardBio: { color: '#8e8e93', fontSize: 13, marginTop: 10, lineHeight: 18 },
  favoriteIconBox: { padding: 16 },
  noFavText: { color: '#666', fontSize: 15, marginTop: 15, textAlign: 'center' },
  menuTitle: { color: '#fff', fontSize: 24, fontWeight: 'bold', paddingHorizontal: 20, paddingTop: 20 },
  mapGraphic: { width: '90%', backgroundColor: '#121212', padding: 22, borderRadius: 15, marginTop: 15, borderWidth: 1, borderColor: '#222' },
  mapPin: { color: '#fff', fontSize: 15, marginVertical: 10, fontWeight: '500' },
  artistSquareImage: {
    width: 50,
    height: 50,
    borderRadius: 8,
    marginRight: 12,
    resizeMode: 'cover',
    backgroundColor: '#222'
  },
  
  // MODAL (ADATLAP) STÍLUSOK
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.85)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#121212',
    borderTopLeftRadius: 25,
    borderTopRightRadius: 25,
    paddingTop: 20,
    maxHeight: '85%',
    borderWidth: 1,
    borderColor: '#222',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingBottom: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#222',
  },
  modalTitle: {
    color: '#666',
    fontSize: 12,
    fontWeight: 'bold',
    letterSpacing: 2,
  },
  closeIcon: {
    padding: 2,
  },
  modalScroll: {
    padding: 20,
    alignItems: 'center',
  },
  modalArtistImage: {
    width: 160,
    height: 160,
    borderRadius: 20,
    resizeMode: 'cover',
    marginBottom: 15,
    borderWidth: 2,
    borderColor: '#1f1f1f',
  },
  modalArtistName: {
    color: '#fff',
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 15,
  },
  modalInfoRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    width: '100%',
    marginBottom: 25,
  },
  modalTag: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1c1c1e',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    marginHorizontal: 5,
    borderWidth: 1,
    borderColor: '#2c2c2e',
  },
  modalTagText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  modalBioTitle: {
    color: '#00FFCC',
    fontSize: 14,
    fontWeight: 'bold',
    alignSelf: 'flex-start',
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: 8,
  },
  modalBioText: {
    color: '#aaa',
    fontSize: 14,
    lineHeight: 22,
    textAlign: 'left',
    width: '100%',
    marginBottom: 30,
  },
  modalCloseButton: {
    backgroundColor: '#00FFCC',
    width: '100%',
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 10,
  },
  modalCloseButtonText: {
    color: '#000',
    fontWeight: 'bold',
    fontSize: 14,
    letterSpacing: 1,
  },
});